import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  items = [];
  total = 0;

  addToCart(product) {
    this.items.push(product);
    this.total += product.price;
  }

  getItems(){
    return this.items;
  }
  
  getTotal(){
    return this.total;
  }

  clearCart(){
    this.items = [];
    return this.items;
  }

  clearTotal(){
    this.total= 0;
    return this.total
  }

  getShippingPrices(){
    return this.http.get('/assets/shipping.json');
  }

  constructor(
    private http: HttpClient
  ) { }

}